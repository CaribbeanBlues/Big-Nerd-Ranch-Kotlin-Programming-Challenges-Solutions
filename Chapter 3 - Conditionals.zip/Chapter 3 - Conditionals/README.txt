Challenge: Enhancing the Aura
Before you start this challenge or the next one, close NyetHack and create a copy of it using your file explorer. You will be making changes to your program that you will not want to keep for future chapters. Name your copy NyetHack_ConditionalsChallenges or whatever you would like. You will want to do this before starting the challenges in future chapters as well.

Currently, if an aura is displayed, it is always green. For this challenge, have the color of the player’s aura reflect their current karma.

Karma has a numeric value from 0 to 20. To determine the player’s karma, use the following formula:

    val karma = (Math.pow(Math.random(), (110 - healthPoints) / 100.0) * 20 ).toInt()
Have the displayed aura follow these rules:

Karma value	Aura color
0-5	red
6-10	orange
11-15	purple
16-20	green
Determine the karma value with the formula above and check the player’s aura color using a conditional expression. Finally, modify the player status display to report the new color if the aura is visible.


Challenge: Configurable Status Format
Currently, the player’s status display is created by two calls to println. There is no variable that holds the value of the full display string.

The code looks like this:

    // Player status
    println("(Aura: $auraColor) " +
            "(Blessed: ${if (isBlessed) "YES" else "NO" })")
    println("$name $healthStatus")
And it produces output like this:

    (Aura: GREEN) (Blessed: YES)
    Madrigal has some minor wounds but is healing quite quickly!
For this more difficult challenge, make the status line configurable with a status format string. Use the character B for blessed, A for aura color, H for healthStatus, and HP for healthPoints. For example, a status format string of:

    val statusFormatString = "(HP)(A) -> H"
should generate a player status display like:

    (HP: 100)(Aura: Green) -> Madrigal is in excellent condition!