Challenge: Single-Expression Functions
Earlier, you saw the single-expression function syntax as a way to make functions that execute one statement more concise. Can you convert auraColor to use the single-expression function syntax?

Challenge: Fireball Inebriation Level
Casting fireballs does not just print a message to the console. While NyetHack fireballs are more delicious than strong, they do have an intoxicating effect on the caster. Make the castFireball function return a resulting inebriation value that depends on the number of fireballs cast. The inebriation value should be between 1 and 50, with 50 being the maximum level of intoxication in the game.

Challenge: Inebriation Status
Building on your last challenge, display the player’s inebriation status based on the inebriation value returned from castFireball. Have the displayed inebriation status follow these rules:

Inebriation level	Inebriation status
1-10	tipsy
11-20	sloshed
21-30	soused
31-40	stewed
41-50	..t0aSt3d