Challenge: “Quit” Command
Players will most likely want to quit NyetHack at some point, and currently NyetHack offers no way to do that. Your challenge is to fix this. When a user enters “quit” or “exit,” NyetHack should display a farewell message to the adventurer and terminate. Hint: Remember that, currently, your while loop executes forever – a significant part of solving this puzzle is to end that loop conditionally.

Challenge: Implementing a World Map
Remember when we said NyetHack would not feature awesome ASCII graphics? Once you successfully complete this challenge, it will!

Players sometimes get lost in the expansive world of NyetHack, and fortunately you have the power to give them a magic map of the realm. Implement a “map” command that displays the player’s current position in the game world. For a player currently at the tavern, the game interaction should resemble the following:

    > Enter your command: map
    O X O
    O O
The X represents the room the player is currently in.

Challenge: Ring the Bell
Add a “ring” command to NyetHack so that you can ring the bell as many times as you would like from within the town square.

Hint: You will have to make the ringBell function public.