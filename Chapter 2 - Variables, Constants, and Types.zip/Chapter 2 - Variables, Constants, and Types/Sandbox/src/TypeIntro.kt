const val MAX_EXPERIENCE: Int = 5000

fun main(args: Array<String>) {
    val playerName = "Estragon"
    var experiencePoints = 5
    
    // Challenge 1
    var hasSteed = false
    
    // Challenge 2
    val pubName = "The Unicorn's Horn"
    var currentPublican = ""
    var currentGold = 25
    val drinks = listOf("Mead", "Wine", "LaCroix")
    
    experiencePoints += 5
    println(experiencePoints)
    println(playerName)
    
    // Challenge 3
    playerName.reversed()
}