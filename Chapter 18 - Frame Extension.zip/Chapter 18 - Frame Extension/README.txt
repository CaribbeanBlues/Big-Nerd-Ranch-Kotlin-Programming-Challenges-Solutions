Challenge: toDragonSpeak Extension
For this challenge, revisit Tavern.kt. Convert the toDragonSpeak function that you wrote to be a private extension function within Tavern.kt.

Challenge: Frame Extension
The following is a small program that allows a string of an arbitrary size to be displayed in a beautiful ASCII frame that is suitable for printing and hanging on any wall:

    fun frame(name: String, padding: Int, formatChar: String = "*"): String {
        val greeting = "$name!"
        val middle = formatChar.padEnd(padding)
               .plus(greeting)
               .plus(formatChar.padStart(padding))
        val end = (0 until middle.length).joinToString("") { formatChar }
        return "$end\n$middle\n$end"
    }
For this challenge, you will apply what you have learned about extensions. Try refactoring the frame function as an extension that is available for use with any String. An example of calling the new version would look like this:

    print("Welcome, Madrigal".frame(5))

    ******************************
    *     Welcome, Madrigal      *
    ******************************