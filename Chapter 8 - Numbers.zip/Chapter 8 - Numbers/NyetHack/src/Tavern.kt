@file:Suppress("SpellCheckingInspection")

import kotlin.math.roundToInt

const val TAVERN_NAME = "Taernyl's Folly"
const val PINTS_TO_GALLON = 0.125
const val GOLD_TO_DRAGONCOIN = 1.43

var playerGold = 10
var playerSilver = 10
var playerDragoncoin = 5.00

var caskGallons = 5.0
var caskPints = caskGallons / PINTS_TO_GALLON



fun main(args: Array<String>) {
//    Challege One
//    for (i in 1..12) {
//        println("---------------------------------------")
//        println("ORDER #$i")
//        placeOrder("shandy,Dragon's Breath,5.91")
//        if (i == 12) println("Pints Left: ${caskPints.toInt()}")
//    }

//    placeOrder("elixir,Shirley's Temple,4.12")
    placeOrder("shandy,Dragon's Breath,5.91")
}

fun performPurchase(price: Double): Boolean {
    displayBalance()
    val totalPurse = playerGold + (playerSilver / 100.0)
    if (totalPurse > price) {
        println("Total purse: $totalPurse")
        println("Purchasing item for $price")

        val remainingBalance = totalPurse - price
        println("Remaining balance: ${"%.2f".format(remainingBalance)}")

        val remainingGold = remainingBalance.toInt()
        val remainingSilver = (remainingBalance % 1 * 100). roundToInt()
        playerGold = remainingGold
        playerSilver = remainingSilver
        displayBalance()
        return true
    } else {
        println("Sorry, yah don't have enough funds for this!")
        return false
    }
}

private fun displayBalance() {
    println("Player's purse balance: Gold: $playerGold , Silver: $playerSilver")
}

private fun toDragonSpeak(phrase: String) =
        phrase.replace(Regex("[aeiou]")) {
            when (it.value) {
                "a" -> "4"
                "e" -> "3"
                "i" -> "1"
                "o" -> "0"
                "u" -> "|_|"
                else -> it.value
            }
        }

private fun placeOrder(menuData: String) {
    val indexOfApostrophe = TAVERN_NAME.indexOf('\'')
    val tavernMaster = TAVERN_NAME.substring(0 until indexOfApostrophe)
    println("Madrigal speaks with $tavernMaster about their order.")

    val (type, name, price) = menuData.split(',')
    val message = "Madrigal buys a $name ($type) for $price."
    println(message)

    // Challenge 2
//    for (i in 1..5) {
//        val purchaseComplete = performPurchase(price.toDouble())
//
//
//        if (purchaseComplete) {
//            val phrase = if (name == "Dragon's Breath") {
//                caskPints --
//                "Madrigal exclaims ${toDragonSpeak("Ah, delicious $name!")}"
//
//            } else {
//                "Madrigal says: Thanks for the $name."
//            }
//            println(phrase)
//        }
//    }

    performDragonCoinPurchase(price.toDouble())

}

// Challenge 3
fun performDragonCoinPurchase(price: Double) {
    val dragoncoinPrice = price / GOLD_TO_DRAGONCOIN
    println("Total Dragoincoins: $playerDragoncoin")
    println("Purchasing item for ${"%.4f".format(dragoncoinPrice)} dragoncoins")

    playerDragoncoin = (playerDragoncoin - dragoncoinPrice)
    println("Remaining dragoncoin balance: ${"%.4f".format(playerDragoncoin)}")
}
