Challenge: Remaining Pints
When a Dragon’s Breath is sold, it is drafted from the cask, which holds 5 gallons. Assuming an order is one pint (.125 gallons), track the remaining quantity of Dragon’s Breath. Display the number of pints left in the cask after 12 pints have been sold.

Challenge: Handling a Negative Balance
Currently, Madrigal can place an order no matter how little gold and silver is in their purse – even if there is none. This is an unsustainable business model for Taernyl’s Folly. In this challenge you will correct that.

Update the code for performPurchase to determine whether the purchase can be performed. If it cannot, no money should change hands, and instead of the message "Madrigal buys a Dragon’s Breath (shandy) for 5.91", a message from the bartender explaining that the customer is short on gold should be printed. To simulate multiple orders, call performPurchase several times in the placeOrder function.

Challenge: Dragoncoin
A new currency is sweeping the land: dragoncoin – instant, secure, and anonymous to spend at any tavern. Assuming the current valuation is 1.43 gold per dragoncoin, represent the player’s purchase in dragoncoin instead of silver and gold. Tavern prices remain defined in gold prices. Your player starts the game with 5 dragoncoin. For a single purchase of Dragon’s Breath that costs 5.91 gold, make sure the player’s remaining dragoncoin balance is .8671 after the purchase.