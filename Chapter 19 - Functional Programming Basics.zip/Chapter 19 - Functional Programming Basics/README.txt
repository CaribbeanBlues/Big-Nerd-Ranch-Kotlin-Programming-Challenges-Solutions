Challenge: Reversing the Values in a Map
Using the functional techniques you learned in this chapter, write a function called flipValues that allows you to flip-flop the keys and values in a map. For example:

    val gradesByStudent = mapOf("Josh" to 4.0, "Alex" to 2.0, "Jane" to 3.0)
    {Josh=4.0, Alex=2.0, Jane=3.0}

    flipValues(gradesByStudent)
    {4.0=Josh, 2.0=Alex, 3.0=Jane}
	
	
Challenge: Applying Functional Programming to Tavern.kt
Tavern.kt could be improved by using some of the functional programming features you learned about in this chapter.

Consider the forEach loop that you use to generate the unique patron names:

    val uniquePatrons = mutableSetOf<String>()

    fun main(args: Array<String>) {
        ...
        (0..9).forEach {
            val first = patronList.random()
            val last = lastName.random()
            val name = "$first $last"
            uniquePatrons += name
        }
        ...
    }
The loop mutates the state of the uniquePatrons set every iteration. This works – but it is possible to do better using a functional programming approach. You might express the uniquePatrons set like this instead:

    val uniquePatrons: Set<String> = generateSequence {
        val first = patronList.random()
        val last = lastName.random()
        "$first $last"
    }.take(10).toSet()
This is an improvement over the old version, because the mutable set is no longer required and you can make the collection read-only.

Notice that the number of uniquePatrons currently varies, depending on chance. For your first challenge, use the generateSequence function to generate exactly nine unique patron names. (Look back at the example in this chapter that generated exactly 1,000 prime numbers for a hint.)

For a second challenge, using what you learned in this section, upgrade the code in Tavern.kt that populates the patron gold map with initial values:

    fun main(args: Array<String>) {
        ...
        uniquePatrons.forEach {
            patronGold[it] = 6.0
        }
        ...
    }
The new version should perform the setup for the patronGold set where the variable is defined, rather than within the main function.

Challenge: Sliding Window
For this advanced challenge, begin with this list of values:

    val valuesToAdd = listOf(1, 18, 73, 3, 44, 6, 1, 33, 2, 22, 5, 7)
Using a functional programming approach, perform the following operations on the valuesToAdd list:

Exclude any number less than 5.

Group the numbers in pairs.

Multiply the two numbers in each pair.

Sum the resulting products to produce a final number.

The correct result is 2,339. Walking through each step, here is what the data should look like along the way:

    Step 1: 1, 18, 73, 3, 44, 6, 1, 33, 2, 22, 5, 7
    Step 2: 18, 73, 44, 6, 33, 22, 5, 7
    Step 3: [18*73], [44*6], [33*22], [5*7]
    Step 4: 1314 + 264 + 726 + 35 = 2339
Notice that step 3 groups the list into sublists of two elements each – this is commonly known as a “sliding window” algorithm (and is where the challenge gets its name). Solving this tricky challenge will require consulting the Kotlin reference documentation – particularly the collections functions at kotlinlang.org/​api/​latest/​jvm/​stdlib/​kotlin.collections/​index.html. Good luck!