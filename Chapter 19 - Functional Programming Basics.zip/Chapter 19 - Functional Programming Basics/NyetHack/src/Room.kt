open class Room(val name: String) {
    protected open val dangerLevel = 5
    var monster: Monster? = Goblin()

    fun description() = "Room: $name\n" +
            "Danger Level: $dangerLevel\n" +
            "Creature: ${monster?.description ?: "none."}"

    open fun load() = "Nothing to see here..."
}

open class TownSquare: Room("Town Square") {
    override val dangerLevel = super.dangerLevel -3
    private var bellSound = "GWONG"

    final override fun load() = "The villagers rally and cheer as you enter!"

    private fun ringBell() = "The Bell tower announces your arrival. $bellSound"
}