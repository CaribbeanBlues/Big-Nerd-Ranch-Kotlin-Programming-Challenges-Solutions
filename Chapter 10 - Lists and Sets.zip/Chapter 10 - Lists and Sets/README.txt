Challenge: Formatted Tavern Menu
First impressions go a long way, and one of the first things a patron will see is the tavern menu. For this challenge, generate a more elegant version of the menu to kick it up a notch. Show the item names capitalized and uniformly aligned. Include the prices, aligned by their decimal points. Format the whole menu in a pleasing block.

The output should resemble the following:

    *** Welcome to Taernyl's Folly ***

    Dragon's Breath...............5.91
    Shirley's Temple..............4.12
    Goblet of LaCroix.............1.22
    Pickled Camel Hump............7.33
    Iced Boilermaker.............11.22
Hint: You will need to calculate the amount of padding for each line by using the longest string from the list of menu items.


Hint: You will need to calculate the amount of padding for each line by using the longest string from the list of menu items.