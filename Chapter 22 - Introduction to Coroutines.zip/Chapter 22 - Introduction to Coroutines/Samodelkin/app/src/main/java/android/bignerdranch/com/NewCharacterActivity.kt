package android.bignerdranch.com

import android.bignerdranch.com.databinding.ActivityNewCharacterBinding
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

private const val CHARACTER_DATA_KEY = "CHARACTER_DATA_KEY"
// Bindings used as Kotlin Lifecycle Extensions has been deprecated
private lateinit var binding: ActivityNewCharacterBinding

private var Bundle.characterData
    get() = getSerializable(CHARACTER_DATA_KEY) as CharacterGenerator.CharacterData
    set(value) = putSerializable(CHARACTER_DATA_KEY, value)

class NewCharacterActivity : AppCompatActivity() {
    private var characterData = CharacterGenerator.generate()
    // Challenge 3

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.characterData = characterData
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewCharacterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        savedInstanceState?.let { characterData = it.characterData } ?: CharacterGenerator.generate()

        binding.generateButton.setOnClickListener {
            liveDataCharacterFetch()
        }
        liveDataCharacterFetch()
    }

    // Challenge Two
    private fun liveDataCharacterFetch() {
        binding.generateButton.isEnabled = false
        GlobalScope.launch(Dispatchers.Main) {
            characterData = fetchCharacterData()
            displayCharacterData()
        }
    }

    private fun displayCharacterData() {
        characterData.run {
            binding.nameTextView.text = name
            binding.raceTextView.text = race
            binding.dexterityTextView.text = dex
            binding.wisdomTextView.text = wis
            binding.strengthTextView.text = str
            // Challenge Three
            binding.generateButton.isEnabled = true
        }
    }
}