**NOTE THAT SINCE COROUTINES ARE NO LONGER EXPERIMENTAL, THIS IMPLEMENTATION DIFFERS FROM THAT OF THE BOOK**

Challenge: Live Data
Currently, the data that is initially shown in the app is static data from the CharacterGenerator object, which is replaced with live data when the GENERATE button is pressed. For this challenge, you will fix that. Make the initial data that is shown in the application live data from the web service instead.

Challenge: Minimum Strength
A character with a strength value lower than 10 will not last more than a few rounds of play in NyetHack. For this challenge, discard any response with a strength value less than 10. Perform new requests until you receive a response with a value of 10 or greater.